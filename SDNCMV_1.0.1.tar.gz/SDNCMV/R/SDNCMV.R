#' Functions for matrix-variate data classification and identification of differential network.
#' 
#' SDNCMV provides tools to implement classification and network comparison for matrix-variate data.
#' 
#' @docType package
#' @name SDNCMV-package
#' @aliases SDNCMV
#' @references 
#' Hao Chen, Ying Guo, Yong He, Jiadong Ji, Lei Liu, Shi Yufeng, Yikai Wang, Yu Long, Zhang Xinsheng (2020) 
#' Simultaneous Differential Network Analysis and Classification for High-dimensional Matrix-variate Data,
#' with application to Brain Connectivity Alteration Detection and fMRI-guided Medical Diagnoses of 
#' Alzheimer's Disease. \emph{arXiv e-prints}, arXiv:2005.08457.
#' 
#' Yikai Wang, Jian Kang, Phebe B. Kemmer and Ying Guo (2016) An efficient and reliable statistical 
#' method for estimating functional connectivity in large scale brain networks using partial correlation.
#' \emph{Frontiers in Neuroence}, \bold{10}, 123.
#' 
#' Tony Cai,Weidong Liu, and Xi Luo (2011) A constrained \eqn{\ell_1} minimization approach for sparse 
#' precision matrix estimation. \emph{Journal of the American Statistical Association} \bold{106}, 594-607.
#' 
#' Diego Franco Saldana and Yang Feng (2018) SIS: An R package for Sure Independence Screening in
#' Ultrahigh Dimensional Statistical Models. \emph{Journal of Statistical Software}, \bold{83}, 1-25.
#' 
#' Jianqing Fan and Rui Song (2010) Sure Independence Screening in Generalized Linear Models with 
#' NP-Dimensionality. \emph{The Annals of Statistics}, \bold{38}, 3567-3604.
#' @examples 
#' \dontrun{
#' conf_var <- rbind(Conf_var_ADHD, Conf_var_TDC)
#' data_net <- ParCor_Trans_mat(X1=ADHD, X2=TDC, confounder=TRUE, conf_var=conf_var, p=116, sis_num=1000)
#' 
#' #Classification
#' # Select 70% samples as training samples in each group, and the remaining samples as test samples.
#' tr1 <- round(0.7*74)
#' tr2 <- round(0.7*109)
#' Y <- data_net$Y_net[c(1:tr1,75:(tr2+75))]
#' X <- data_net$X_net[c(1:tr1,75:(tr2+75)),]
#' New_X <- data_net$X_net[c((tr1+1):74,(tr2+76):183),]
#' prediction <- Classification(X=X,Y=Y,New_X = New_X)
#' 
#' #Identification of Differential Network
#' Y <- data_net$Y_net
#' X <- data_net$X_net
#' p_edge_ind <- data_net$p_edge_ind
#' delta <- Diff_Net(X=X, Y=Y, p=116, p_edge_ind=p_edge_ind)
#' }
NULL