#' @title Identification of Differential Network
#'
#' @description
#' \code{Diff_Net} Identification of Differential Network by a bootstrapped Penalized 
#' Logistic Regression (PLR) Models with elastic-net penalty.
#'
#' @details
#' Identification of Differential Network of two groups. In this function, first, training the bootstrapped 
#' PLR models with elastic-net penalty B times. Then count the number of occurrences of each coefficient 
#' \eqn{\beta_{i,j}} and this number also represents the number of occurrences of each pair of 
#' nodes \eqn{(i,j)}.
#' 
#' @param X Input matrix for bootstrapped Penalized Logistic Regression (PLR) Models. 
#' Each row is an observation vector.
#' @param Y An binary response vector correspond to matrix X.
#' @param B Times of bootstrap. Default is 200.
#' @param p Row dimension of original matrix-valued data. For example, in fMRI data the p is the number
#' of ROIs.
#' @param p_edge_ind If SIS is called, this parameter is the index of each edge selected by SIS in the 
#' previous p*(p-1)/2 edges. If SIS is not called, ignore this parameter. Defalut is \code{NULL}.
#' @param alpha The elastic-net mixing parameter with \eqn{0 \leq \alpha \leq 1}. alpha=1
#' is the lasso penalty, and alpha=0 is the ridge penalty. Default is 0.1.
#' @export
#' @import stats
#' @import glmnet
#' @return A symmetric delta matrix, of dimensions p*p. Each element represents the number of occurrences
#' of each pair of nodes \eqn{(i,j)}.
#' @author Hao Chen, Yong He, Jiadong Ji
#' @examples
#' \dontrun{
#' Y <- data_net$Y_net
#' X <- data_net$X_net
#' p_edge_ind <- data_net$p_edge_ind
#' delta <- Diff_Net(X=X, Y=Y, p=116, p_edge_ind=p_edge_ind)
#' }
Diff_Net <- function(X, Y, B=200, p, p_edge_ind=NULL, alpha=0.1){
        boot_strap <- B
        n <- nrow(X)
        delta <- matrix(nrow=boot_strap,ncol=p*(p-1)/2)
        for (j in 1:boot_strap) {
                ids_diff <- sample(n, n, replace=T)
                
                X_vec_diff <- X[ids_diff,]
                Y_vec_diff <- Y[ids_diff]
                
                cv.fit_diff <- cv.glmnet(X_vec_diff,Y_vec_diff,family='binomial',type.measure="class",alpha=alpha)
                coefficients <- coef(cv.fit_diff,s=cv.fit_diff$lambda.min)
                diff <- as.vector(coefficients[-1]) 
                for (i in 1:(p*(p-1)/2)) {
                        delta[j,i] <- 0
                }
                
                if(is.null(p_edge_ind)){
                        delta[j,i] <- diff[i]
                }else{
                        for (i in 1:(p*(p-1)/2)) {
                                delta[j,p_edge_ind[i]] <- diff[i]    
                        }
                }

                
                for (i in 1:(p*(p-1)/2)) {
                        if (delta[j,i]!=0){
                                delta[j,i]<-1                        
                        }
                }
        }
        delta_sum <- colSums(delta)
        delta_matrix <- matrix(rep(0,(p*p)),nrow=p,ncol=p)
        delta_matrix[upper.tri(delta_matrix,diag=F)] <- delta_sum
        delta_matrix <- delta_matrix + t(delta_matrix)
        return(delta_matrix)
}
