#' @title Confounders for TDC subjects in ADHD-200 Global Competition Dataset from Peking University site
#'
#' @description Dataset of three confounders including gender, age and handedness for subjects in the TDC
#' group.
#'
#' @docType data
#' @keywords datasets
#' @name Conf_var_TDC
#' @usage data(Conf_var_TDC)
#' @format A matrix with 109 rows and 3 columns, where the rows correspond to the TDC subjects and the columns
#' correspond to the confounders.
#' @source The data set can be downloaded from the website: http://fcon1000.projects.nitrc.org/indi/adhd200/
NULL