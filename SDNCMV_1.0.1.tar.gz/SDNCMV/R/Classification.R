#' @title Train bootstrapped Penalized Logistic Regression (PLR) Models with elastic-net penalty
#' and makes prediction for new data.
#'
#' @description
#' \code{Classification} Train bootstrapped Penalized Logistic Regression (PLR) Models with 
#' elastic-net penalty and makes prediction for new data.
#'
#' @details
#' Classifier by training data X and Y, and then make predictions for new data New_X
#' 
#' @param X Input matrix for bootstrapped Penalized Logistic Regression (PLR) Models. 
#' Each row is an observation vector.
#' @param Y An binary response vector correspond to matrix X.
#' @param New_X Matrix of new values for X at which predictions are to be made.
#' @param B Times of bootstrap. Default is 200.
#' @param alpha The elastic-net mixing parameter with \eqn{0 \leq \alpha \leq 1}. alpha=1 
#' is the lasso penalty, and alpha=0 is the ridge penalty. Default is 0.1.
#' @export
#' @import stats
#' @import glmnet
#' @return An binary outcome for new data New_X.
#' @author Hao Chen, Yong He, Jiadong Ji
#' @examples
#' \dontrun{
#' # Select 70% samples as training samples in each group, and the remaining samples as test samples.
#' tr1 <- round(0.7*74)
#' tr2 <- round(0.7*109)
#' Y <- data_net$Y_net[c(1:tr1,75:(tr2+75))]
#' X <- data_net$X_net[c(1:tr1,75:(tr2+75)),]
#' New_X <- data_net$X_net[c((tr1+1):74,(tr2+76):183),]
#' prediction <- Classification(X=X,Y=Y,New_X = New_X)
#' }
#' 
Classification <- function(X, Y, New_X, B = 200, alpha = 0.1){
        boot_strap <- B
        n <- nrow(X)
        Y_pre <- matrix(nrow=boot_strap,ncol=(nrow(New_X)))
        
        for (j in 1:boot_strap) {
                ids <- sample(1:n, n, replace=T)
                X_tr <- X[ids,]
                Y_tr <- Y[ids]
                cv.fit <- cv.glmnet(X_tr,Y_tr,family='binomial',type.measure="class",alpha=alpha)
                Y_pre[j,] <- as.vector(as.numeric(predict(cv.fit, newx = New_X, s = "lambda.min", type = "class",alpha=alpha)))
        }
        
        Y_pre.vote<-array()
        #classification error vote
        for (i in 1:(nrow(New_X))) {
                if(sum(Y_pre[,i])>(boot_strap/2)){
                        Y_pre.vote[i]<-1
                } else if(sum(Y_pre[,i])<(boot_strap/2)){
                        Y_pre.vote[i]<-0
                } else if(sum(Y_pre[,i])==(boot_strap/2)){
                        Y_pre.vote[i]<-sample(c(0,1),1)
                }
        }
        return(Y_pre.vote)
}
