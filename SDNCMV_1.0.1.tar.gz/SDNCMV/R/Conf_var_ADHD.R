#' @title Confounders for ADHD subjects in ADHD-200 Global Competition Dataset from Peking University site
#'
#' @description Dataset of three confounders including gender, age and handedness for subjects in the ADHD
#' group.
#'
#' @docType data
#' @keywords datasets
#' @name Conf_var_ADHD
#' @usage data(Conf_var_ADHD)
#' @format A matrix with 74 rows and 3 columns, where the rows correspond to the ADHD subjects and the columns
#' correspond to the confounders.
#' @source The data set can be downloaded from the website: http://fcon1000.projects.nitrc.org/indi/adhd200/
NULL