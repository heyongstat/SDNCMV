#' @title Processed TDC group data from Peking University site in ADHD-200 Global Competition Dataset
#'
#' @description There are 109 subjects in the TDC group. For each subject, the data is in a temporal*spatial 
#' data matrix form, with spatial dimension 116 (ROIs) and temporal dimension 232.
#' 
#' @docType data
#' @keywords datasets
#' @name TDC
#' @usage data(TDC)
#' @format A list.
#' \describe{
#' \item{TDC}{a list with 109 matrices, and each matrix is of dimension 232*116.}
#' }
#' @source The data set can be downloaded from the website: http://fcon1000.projects.nitrc.org/indi/adhd200/
NULL
