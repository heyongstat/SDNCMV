#' @title Processed ADHD group data from Peking University site in ADHD-200 Global Competition Dataset
#'
#' @description There are 74 subjects in the ADHD group. For each subject, the data is in a temporal*spatial 
#' data matrix form, with spatial dimension 116 (ROIs) and temporal dimension 232.
#'
#' @docType data
#' @keywords datasets
#' @name ADHD
#' @usage data(ADHD)
#' @format A list.
#' \describe{
#' \item{ADHD}{a list with 74 matrices, and each matrix is of dimension 232*116.}
#' }
#' @source The data set can be downloaded from the website: http://fcon1000.projects.nitrc.org/indi/adhd200/
NULL